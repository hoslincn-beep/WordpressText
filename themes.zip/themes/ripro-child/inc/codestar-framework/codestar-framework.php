<?php
if (!class_exists('CSF')) {
    require_once get_template_directory() . '/inc/codestar-framework/codestar-framework.php';
}
require_once plugin_dir_path(__FILE__) . 'options/admin-options.php';
require_once plugin_dir_path(__FILE__) . 'options/metabox-options.php';