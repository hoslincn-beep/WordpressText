<?php 

echo '<div class="article-copyright">'._cao('post_copyright').'<br/><a href="'.get_bloginfo('url').'">'.get_bloginfo('name').'</a> &raquo; <a href="'.get_permalink().'">'.get_the_title().'</a></div>';
?>


